# 前言
qbittorrent是一款开源的bt下载神器
开源地址：https://github.com/c0re100/qBittorrent-Enhanced-Edition
官网：https://www.qbittorrent.org/

首先打开qbittorrent的设置，接着按教程设置即可
# 1、行为
取消勾选`检查程序更新`
勾选`下载/做种时禁止系统休眠`
# 2、下载
在`下载`里设置`默认保存路径`和`对不完整的torrent使用另一个路径`。如果你更换了系统并且保存了原系统的一些种子文件，你可以在`自动从此处添加torrent`添加种子文件的目录，做到自动识别，批量下载
# 3、连接
`连接`里设置`连接限制`，分别对应为
> 全局最大连接数---2000
> 每torrent最大连接数---200
> 全局上传窗口数上限---200
> 每个torrent上传窗口数上限---50

# 4、速度
`速度限制`里`下载速度`都不限制(无穷)，`全局速度限制`里的`上传速度`可以设置为自己带宽的一半，避免影响正常使用，这里设置`2048kb/s`，`备用速度限制`里的`上传速度`,设置为`1024kb/s`
ps：当然，我推荐你上传速度设置为不限制，因为bt精神是伟大的！
# 5、Bitterront
勾选`torrent队列`，`最大活动下载数`改为`5`（不要太大），其余两项都改为`无限制（无穷）` ，在下方勾选`Automatically update public trackers list`（自动将以下tracker添加到新的任务），将这个地址复制进去https://jsd.cdn.zzko.cn/gh/XIU2/TrackersListCollection/best.txt  
其实这个就是tracker服务器的列表，你可以打开网站看一看，然后点击refetch更新一下地址
# 6、RSS*
我目前手里没有群晖、nas这类东西，以后有了再完善该部分
# 7、Wbe UI* 
`Wbe UI`可用于远程控制`qbitterront`客户端  
我目前手里没有群晖、nas这类东西，以后有了再完善该部分
# 8、高级设置
`高级设置`里勾选`总是向同级的所有tracker汇报`和`总是向所有等级的tracker汇报`
# 9、最重要！！！！！
`最重要的一点，别忘了点确定！！！！！！！不然就白配置了`