# 安装Docker与Docker-Compose
## 国外服务器
### 安装docker
```
wget -qO- get.docker.com | bash
```
检查是否安装成功
```
docker -v
```
设置开机自启动
```
systemctl enable docker
```

### 安装Docker-Compose
```
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```
给予执行权限
```
sudo chmod +x /usr/local/bin/docker-compose
```
检查是否安装成功
```
docker-compose --version
```

## 国内服务器
### 安装Docker
```
curl -sSL https://get.daocloud.io/docker | sh  
```
检查是否安装成功
```
docker -v
```
设置开机自启动
```
systemctl enable docker
```

### 安装Docker-Compose
```
curl -L https://get.daocloud.io/docker/compose/releases/download/v2.1.1/docker-compose-`uname -s`-`uname -m` > /usr/local/bin/docker-compose
```
给予执行权限
```
chmod +x /usr/local/bin/docker-compose
```
检查是否安装成功
```
docker-compose --version
```