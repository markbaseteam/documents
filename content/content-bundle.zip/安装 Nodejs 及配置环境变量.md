# 前言
为什么要安装nodejs，如果你之前还没有了解过nodejs，那么我推荐你阅读一下知乎上的这篇文章[nodejs有什么用](https://www.zhihu.com/question/33578075),如果你之前搭建过静态博客，那么你一定看到人家要求首先你安装nodejs和git，git好配置，就不再赘述
> 但是由于nodejs安装在windows上总是遇到一些奇怪的问题，其中最主要的原因就是环境变量没有配置好，于是写了这篇文章来教大家安装nodejs并配置好环境变量

# 1.下载并安装Nodejs(最好14.0以上版本)

- [nodejs中文网](http://nodejs.cn/)  
- [nodedjs官网](https://nodejs.org/en/)

ps: 这两个网站任选一个就行，安装过程中，除了安装位置根据个人需要改变(建议安装在非系统盘)，其余无脑下一步即可，请记好你设置的安装目录，下面要用到  

# 2.配置环境变量及一些设置
## 配置环境变量
安装完成之后我们打开安装目录，在**nodejs安装目录**下新建两个文件夹

- 1.node_cache  
- 2.node_global

接着我们在windows搜索框中搜索**环境变量**，打开**编辑系统环境变量**，再点击**环境变量**，首先双击**用户变量**里的**path**，点击**新建**，选择**nodejs的安装目录**
这里我的nodejs的安装目录是*D:\Program File\node-v16.18.1-win-x64*，我就把它填进去即可，点击**确定**

然后我们在系统变量下点击**新建**，变量名填写**NODE_HOME**，值填写**nodejs的安装目录**
这里我的就填*D:\Program File\node-v16.18.1-win-x64*
点击**确定**；再在**系统变量**点击**新建**，变量名填写**NODE_PATH**，值填写 **nodejs安装目录/node_modules**
这里我的就填*D:\Program File\node-v16.18.1-win-x64\node_modules*。接着找到**系统变量**里的**Path**

进入，新建三个环境变量，分别为  
- %NODE_HOME%  
- %NODE_HOME%\node_cache  
- %NODE_HOME%\node_global

最后一路确定即可。
## 输入命令进一步完善
配置完成之后我们打开cmd命令行（*这里输出结果以我的电脑为例，请自行类比，如有报错，请复制报错返回值自行百度处理，一般来说，经过上面的配置后，不会有报错问题出现*）

```
输入 node -v
#查看node的版本号，从而验证node是否成功安装
输出 v16.18.1

输入 npm -v
#查看npm的版本号
输出 8.19.2

输入 npm config set prefix "nodejs的安装路径/node_global"
#设置全局变量安装位置
输出 空白

输入 npm config set cache "nodejs的安装路径/node_cache"
#设置缓存位置
输出 空白

输入 npm config set registry https://registry.npm.taobao.org
#由于npm资源在国外，下载速度较慢，这里把npm源换成淘宝的镜像源
输出 空白

输入 npm config ls
#查看安装情况
输出 ; "user" config from C:\Users\yuyun.npmrc
cache = "D:\Program File\node-v16.18.1-win-x64\node_cache" prefix = "D:\Program File\node-v16.18.1-win-x64\node_global" registry = "https://registry.npm.taobao.org/"
; node bin location = D:\Program File\node-v16.18.1-win-x64\node.exe ; node version = v16.18.1 ; npm local prefix = C:\Users\yuyun ; npm version = 8.19.2 ; cwd = C:\Users\yuyun ; HOME = C:\Users\yuyun ; Run npm config ls -l to show all defaults.
#自己类比即可，不报错即为正常

输入 npm install -g cnpm
#测试npm安装命令是否正常
输出 不报错即为正常，出现警告忽视即可，输出结果最后一行为add xxxxxxxx 即正常
#这个时候我们就可以在在 nodejs的安装目录/node_global目录中看到cnpm的一些包

输入 cnpm -v
#查看cnpm的版本号
输出 cnpm@9.0.1 (D:\Program File\node-v16.18.1-win-x64\node_global\node_modules\cnpm\lib\parse_argv.js) npm@8.19.3 (D:\Program File\node-v16.18.1-win-x64\node_global\node_modules\cnpm\node_modules\npm\index.js) node@16.18.1 (D:\Program File\node-v16.18.1-win-x64\node.exe) npminstall@7.2.2 (D:\Program File\node-v16.18.1-win-x64\node_global\node_modules\cnpm\node_modules\npminstall\lib\index.js) prefix=D:\Program File\node-v16.18.1-win-x64\node_global win32 x64 10.0.22621 registry=https://registry.npmmirror.com
#类比即可，不报错即为正常
```
# 3.用Nodejs安装yarn（可选）
以下命令不报错即为正常，报错请复制返回值自行百度处理
```
输入 npm install --global yarn
#安装yarn
输入 yarn config set registry https://registry.npm.taobao.org
#切换镜像源为淘宝镜像，提高下载速度
输入 yarn --version
#查看yarn版本及yarn是否安装完成
```