# 修改nginx.conf文件
如果需要反向代理某个端口，修改以下模板，将其添加到nginx.conf的http{}内
```
	server {
		listen 80;
		listen 443 ssl;
		server_name cloud.waynet.top;
		ssl_certificate  /etc/cloudreve/server.crt; #需要修改
		ssl_certificate_key  /etc/cloudreve/server.key; #需要修改

		# http 强制跳转 https
		if ($scheme = http ) {
		return 301 https://$host$request_uri;
		}

		location / {
		proxy_redirect off;
		proxy_pass http://127.0.0.1:7262;  #需要修改

		proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
		proxy_set_header Host $http_host;
		proxy_set_header X-Real-IP $remote_addr;
		proxy_set_header Range $http_range;
		proxy_set_header If-Range $http_if_range;
		}
	}
```

其中`/etc/cloudreve/server.crt`需要修改为你申请的ssl证书的crt文件的位置  
`/etc/cloudreve/server.key`需要修改为你申请的ssl证书的key文件的位置  
`7262`修改为你需要反向代理的端口

# 申请ssl证书
```
#更新软件源
apt update
#启用 BBR TCP 拥塞控制算法
echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
sysctl -p

#安装nginx
apt install nginx
#安装acme：
curl https://get.acme.sh | sh
#添加软链接：
ln -s  /root/.acme.sh/acme.sh /usr/local/bin/acme.sh
#切换CA机构： 
acme.sh --set-default-ca --server letsencrypt
#申请证书： 
acme.sh  --issue -d 你的域名 -k ec-256 --webroot  /var/www/html
#安装证书：
acme.sh --install-cert -d 你的域名 --ecc --key-file  /etc/cloudreve/server.key  --fullchain-file /etc/cloudreve/server.crt --reloadcmd     "systemctl force-reload nginx"
```

其中`/etc/cloudreve/server.crt`需要修改为你需要安装的ssl证书的crt文件的位置  
`/etc/cloudreve/server.key`需要修改为你需要安装的ssl证书的key文件的位置  
`你的域名`替换为你需要申请证书的域名，先dns解析在申请，不然会出错