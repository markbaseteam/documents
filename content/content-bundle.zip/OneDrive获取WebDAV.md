# 前言
OneDrive的WebDav的获取需要用到**koofr**这一挂载网盘的网站
# 注册并配置koofr
谷歌登录[**koofr**](https://app.koofr.net/)后，在左侧connect选项下选择onedrive
![koofr1](https://img.wayner.top/i/2023/02/15/63ec79dddf029.png)

如果使用的是微软E5开发者计划，登录后会显示**OneDrive for business**而不是**OneDrive**，请在**Places**中把名字改为**OneDrive**

接着点击右上角头像选择Preference
![koofr2](https://img.wayner.top/i/2023/02/15/63ec79f6a3241.png)

在preference中找到password
![koofr3](https://img.wayner.top/i/2023/02/15/63ec7b3b3001c.png)

滑到下方找到APP password，任意起一个有助于你辨别的名字，点击generate，即可生成密钥
![koofr4](https://img.wayner.top/i/2023/02/15/63ec7a4e76ef4.png)

复制绿色框里的密钥
![koofr5](https://img.wayner.top/i/2023/02/15/63ec7a678028c.png)
# webdav的使用
之后如果遇到需要填写 webdav 的信息  
地址填写`https://app.koofr.net/dav/onedrive`  
密码填写刚刚复制的`密钥`即可