> 首先声明，搭建hexo博客是很简单的一件事，甚至你可以不花一分钱就拥有一个属于自己的博客网站，也就是将hexo部署到GitHub Pages上，当然你也可部署到自己的服务器上，它们各有各的优缺点

| 部署方式 | 优点 | 缺点 |
| --- | --- | --- |
| **GitHub Pages** | 永久免费，部署简单 | 访问速度较慢，国内访问经常抽风 |
| **云服务器** | 访问速度快，管理方便 | 收费，部署复杂 |

你可以根据自己的需求来选择两种部署方式，当然，如果你是第一次部署hexo博客，我推荐你先用GitHub Pages 来练手

# 一，部署到本地
## 1.安装nodejs和git
git的安装非常简单，你只需要去git的官网下载git，一路下一步安装（安装目录建议选择非系统盘）即可，无需配置环境变量。  
git官网链接: https://git-scm.com/

nodejs的安装较为复杂，因为它需要配置环境变量，为此我专门写了一篇文章来安装并配置nodejs

## 2.安装hexo
### 选择博客文件目录
我们选择任意一个目录来存放我们博客文件的位置，这里我在D:\Program File\下新建了一个文件夹，命名为Blog，注意文件夹必须为空文件夹

### 使用git安装hexo
在Blog目录下右键，点击*git Bash here*，然后输入命令
```
npm install -g hexo-cli
``` 
接着我们通过检测hexo的版本号来查看hexo是否安装成功
```
hexo -v
```
然后我们进行hexo初始化，这时你就能在Blog目录看到一些文件了
```
hexo init
```
然后我们来安装hexo需要的一些依赖
```
npm install
```
这样我们的安装工作就完成了

## 3.本地启动
首先我们先生成html文件，这样我们才能看到网页
```
hexo g
```
然后我们启动hexo服务
```
hexo s
```
这样我们就可以通过浏览器访问http://localhost:4000/ 来访问我们部署的博客啦

你看到的应该是这样的界面：
![hexo.img](https://img.wayner.top/i/2023/02/13/63ea2647d5654.jpg)

大功告成，恭喜你完成了hexo博客的搭建

## 4.安装主题
hexo默认界面太过于难看，我们当然是要选择一款自己喜爱的主题来安装，这里我就一fluid主题为例  
fluid开源地址: https://github.com/fluid-dev/hexo-theme-fluid

首先说一下，我们的主题文件默认都是放在./themes 下的

我们先暂停刚刚启动的hexo服务，按住快捷键`Ctrl`+`C`即可暂停，这样我们就能继续输入命令了

首先我们将fluid的主题文件克隆过来，输入
```
cd themes
git clone https://github.com/fluid-dev/hexo-theme-fluid
```
如果提示你失败（也就是出现error等字样，是GitHub在国内的访问原因，你可以自己配置ssh来进行克隆），多试几次，如果还是不行，那你就直接访问fluid的开源地址，点击`code`,再点击`Download ZIP`,然后将压缩包解压到themes文件夹下即可
![github.img](https://img.wayner.top/i/2023/02/13/63ea2649eff9a.jpg)

然后我们需要修改根目录下的_config.yml文件，直接通过记事本或者vscode打开，接着找到最下面的`themes:`，将其值修改为fluid

这样fluid主题就正式安装完成并且切换成功了

我们重新生成页面并且启动服务查看效果即可
```
hexo g
hexo s
```
访问http://localhost:4000/
![fluid.img](https://img.wayner.top/i/2023/02/13/63ea2642acf6a.jpg)

## 5.撰写文章
博客搭建完了，写一篇文章发表一下你的感想吧

首先说明，hexo的文章遵循Markdown语法，所以要想写出观感较好的文章，我建议你先去学习markdown语法  
Markdown语法官方文档:https://markdown.com.cn/basic-syntax/
不用担心很复杂，语法非常简单，记住几个常用的就行，剩下的忘了再去查就是

我们来生成一篇博客文章，输入
```
hexo new "文章的标题"
```
文章的md文件默认存放在./source/_post/下

我们来到该目录打开该md文件，可以看到被“- - -”包括的三个变量，分别是
- title - ->该博客文章的标题
- date  - ->生成该文章的日期
- tags  - ->该文章的标签

当然你也可以指定其他的变量，这里先不阐述
在“- - -”下面就是你撰写文章内容的地方，你可以采用markdown语法来写出自己的文章

**尽情书写你的感想吧！！！**

书写完毕之后记得保存文件，然后生成页面并启动服务
```
hexo g
hexo s
```