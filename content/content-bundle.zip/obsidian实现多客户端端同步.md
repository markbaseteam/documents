# 前言
Obsidian是一款功能及其强大的笔记软件，其强大之处在于它是开源的，拥有插件仓库，可以满足你的各种需求，并且拥有简洁优秀的外观
先上成品图
![obsidian1](https://img.wayner.top/i/2023/02/15/63ec8446ef23b.jpg)
左侧文件目录（可折叠）和一些工具，右侧文章大纲，中间文章内容
是你心目中的笔记吗
但是obsidian的同步功能是要收费的，而且价格还不低，所以我们可以采用第三方插件的方式来解决同步问题

# 1、下载第三方插件 
在obsidian自带的第三方插件仓库下载安装`remotely save`第三方插件(需要科学)
# 2、配置webdav
Webdav可以选择OneDrive或者坚果云，不过经过反馈，**坚果云可能存在备份失败，在安卓上不兼容等问题**，推荐使用OneDrive  

关于获取OneDrive的WebDav，教程链接
https://wayner.top/archives/onedrive%E8%8E%B7%E5%8F%96webdav

4，然后在**koofr**的**preference**中选择**password**，下滑找到**APP password**生成Webdav即可

>**请复制生成的密钥，配置remotely save要用到！**

5，打开**Obsidian**的第三方插件**remotely save**，选择webdav，输入服务器地址https://app.koofr.net/dav/onedrive  (这个地址最后的onedrive并不是固定的，你可以填写自己给网盘的命名)，并填入注册**OneDrive**时填写的邮箱和刚刚生成的密钥，这样就大功告成了！

>你也可以根据自己的习惯，设置remotely save的自动同步和启动时即可同步，*我设置的的是一分钟同步一次和启动后1秒自动同步*