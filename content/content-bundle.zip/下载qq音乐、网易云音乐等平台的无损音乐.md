# 前言
近来想把自己qq音乐的歌单下载到本地以防止版权失效，一直没有找到合适的下载工具，直到发现了这个GitHub项目  
**项目链接**：https://github.com/QiuChenly/QQFlacMusicDownloader

赶紧体验了一番，效果非常棒，它有如下优点：
- 满速下载，跑满了我的带宽
- 支持网易云会员、QQ音乐、酷我音乐
- 具有前端界面，教程写的十分详细，对新手友好
- 支持歌单、专辑下载

下面我以Windows系统为例，简单写一下使用教程

# 安装环境与必需环境

## 安装Python 3.11.2
据作者所说，**必需安装python3.11.2 这个版本**  
下载地址： https://www.python.org/ftp/python/3.11.2/python-3.11.2-amd64.exe

我自己没试其他版本，直接按他的来，安装了这个版本的Python

**需要注意的是，作者也强调了不要把Python安装在有空格的路径里，如Python的默认路径C:/Program Files(x86)/ 就有空格，于是我安装在了其他地方，安装的时候记得勾选添加到环境变量**

## 安装依赖
找个地方把项目clone下来（别在C盘，除非你只有一个盘）
```
git clone git@github.com:QiuChenly/QQFlacMusicDownloader.git
```
进入目录
```
cd QQFlacMusicDownloader
```
安装依赖
```
pip3 install -r requirements.txt
```
如果安装速度过慢，可以先设置镜像源再安装依赖
```
pip3 config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

# 运行
执行命令
```
python3 MainServer.py
```
如果没反应，执行
```
python MainServer.py
```

弹出防火墙请求，请允许，然后不关闭终端，浏览器进入http://127.0.0.1:8899/

出现网页即为成功，自己看一下就知道如何使用了  
分享一下常用的搜索方法：点击侧边栏`音乐搜索`，输入p:歌单号，即可下载歌单所有歌曲，下载目录默认保存在`你clone的路径/music/ 文件夹、下`

尽情享受无损音质带来的快感吧！这种项目可能早晚会挂，请尽快使用，**并且不要分享到国内平台！！！**